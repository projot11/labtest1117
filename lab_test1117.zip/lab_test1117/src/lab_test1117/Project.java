package lab_test1117;

public class Project {
	Team team;
	Sprint sprint1;
	Sprint sprint2;
	public Project(Team team, Sprint sprint1, Sprint sprint2) {
		// TODO Auto-generated constructor stub
		this.team=team;
		this.sprint1=sprint1;
		this.sprint2=sprint2;
		
	}

	

}
