package lab_test1117;

public interface teamMember {
	String role="";

	void setRole(String task);

	Object getRole();
	

}
