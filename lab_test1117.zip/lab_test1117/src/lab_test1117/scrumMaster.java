package lab_test1117;

public class scrumMaster implements teamMember {
	String role="";

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

}
