package lab_test1117;

public class Team {
	  teamMember productowner;
	  teamMember scrummaster;
	  teamMember programmer;
	  teamMember tester;
	  int velocity=20;
	
	public Team(teamMember productowner, teamMember scrummaster, teamMember programmer, teamMember tester) {
		// TODO Auto-generated constructor stub
		this.productowner=productowner;
		this.scrummaster=scrummaster;
		this.programmer= programmer;
		this.tester=tester;
		
	}

	
}
