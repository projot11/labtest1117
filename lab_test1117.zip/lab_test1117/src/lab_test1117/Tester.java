package lab_test1117;

public class Tester implements teamMember {
	String role="";

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}
}
