package lab_test1117;

public class Sprint {

	Story story1;
	Story story2;
	public Sprint(Story story1, Story story2) {
		// TODO Auto-generated constructor stub
		this.story1=story1;
		this.story2=story2;
	}
	
  public void taskAllocation()
  {
	  
  }
	
}
