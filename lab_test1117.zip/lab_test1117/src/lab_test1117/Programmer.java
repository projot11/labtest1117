package lab_test1117;

public class Programmer implements teamMember {
	String role="";

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

}
