package lab_test1117;

public class Task {
	int hours;
	String task="";

	public String getTask() {
		return task;
	}

	public void setTask(String task) {
		this.task = task;
	}

	public Task(int i, String string) {
		// TODO Auto-generated constructor stub
		this.hours=i;
		this.task=string;
	}

	

	public int getHours() {
		return hours;
	}

	public void setHours(int hours) {
		this.hours = hours;
	}

}
